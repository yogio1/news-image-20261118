# Soul
Slug: buddy-my-ai-companion
Name: My AI Companion
Summary: yogie2
LightVela-Avatar: blob:#8B5CF6

## Content
yogie2
